#include "driver/gpio.h"          // Biblioteca para controlar os pinos GPIO
#include "freertos/FreeRTOS.h"   // Biblioteca principal do FreeRTOS
#include "freertos/task.h"       // Biblioteca para usar tarefas e delays
#include <stdio.h>               // Biblioteca para usar printf

#define LED_VERDE 18             // Define o pino do LED verde
#define LED_AMARELO 4            // Define o pino do LED amarelo
#define LED_VERMELHO 2           // Define o pino do LED vermelho
#define BUTTON_GPIO 13           // Define o pino do botão
#define DEBOUNCE_LIMIT 3         // Valor de debounce (não utilizado atualmente)

int pedestre_pendente = 0;       // Variável global que guarda pedidos de travessia

// Função responsável por detectar clique válido do botão
int botao_pressionado() {

    // Verifica se o botão foi pressionado
    if (gpio_get_level(BUTTON_GPIO) == 0) {

        // Espera 50ms para evitar falsos cliques (debounce)
        vTaskDelay(pdMS_TO_TICKS(50));

        // Confirma novamente se o botão continua pressionado
        if (gpio_get_level(BUTTON_GPIO) == 0) {

            // Espera o usuário soltar o botão
            while (gpio_get_level(BUTTON_GPIO) == 0) {
                vTaskDelay(pdMS_TO_TICKS(10));
            }

            // Retorna 1 indicando clique válido
            return 1;
        }
    }

    // Retorna 0 caso não tenha clique válido
    return 0;
}

// Função do estado VERDE do semáforo
void seguir () {

    // Liga LED verde
    gpio_set_level(LED_VERDE,1);

    // Mantém o verde ligado durante o loop
    for (int i = 0; i < 50; i++) {

        // Verifica se o botão foi pressionado
        if (botao_pressionado()) {

           // Soma um pedido de travessia
           pedestre_pendente++;

           // Mostra mensagem no terminal
           printf("BOTAO APERTADO\n");

           // Mostra quantidade de pedidos pendentes
           printf("PEDIDOS PENDENTES: %d\n", pedestre_pendente);
        }

        // Delay de 100ms
        vTaskDelay(pdMS_TO_TICKS(100));
    }

    // Desliga LED verde
    gpio_set_level(LED_VERDE,0);
}

// Função do estado AMARELO do semáforo
void atençao () {

    // Liga LED amarelo
    gpio_set_level(LED_AMARELO,1);

    // Mantém amarelo ligado
    for (int i = 0; i < 20; i++) {

        // Verifica botão
        if (botao_pressionado()) {
           
           // Adiciona pedido pendente
           pedestre_pendente++;

           // Mensagem no terminal
           printf("BOTAO APERTADO\n");

           // Mostra quantidade de pedidos
           printf("PEDIDOS PENDENTES: %d\n", pedestre_pendente);
        }

        // Delay de 100ms
        vTaskDelay(pdMS_TO_TICKS(100));
    }

    // Desliga LED amarelo
    gpio_set_level(LED_AMARELO,0);
}

// Função do estado VERMELHO do semáforo
void parar () {

    // Liga LED vermelho
    gpio_set_level(LED_VERMELHO,1);

    // Mantém vermelho ligado
    for (int i = 0; i < 50; i++) {

        // Verifica botão
        if (botao_pressionado()) {
           
           // Soma pedido de travessia
           pedestre_pendente++;

           // Mostra mensagem
           printf("BOTAO APERTADO\n");

           // Mostra pedidos pendentes
           printf("PEDIDOS PENDENTES: %d\n", pedestre_pendente);
        }

        // Delay de 100ms
        vTaskDelay(pdMS_TO_TICKS(100));
    }

    // Desliga LED vermelho
    gpio_set_level(LED_VERMELHO,0);
}

// Função responsável pela travessia do pedestre
void travessia () {

    // Liga LED verde
    gpio_set_level(LED_VERDE,1);

    // Espera 100ms
    vTaskDelay(pdMS_TO_TICKS(100));

    // Desliga LED verde
    gpio_set_level(LED_VERDE,0);

    // Espera 100ms
    vTaskDelay(pdMS_TO_TICKS(100));

    // Liga LED amarelo
    gpio_set_level(LED_AMARELO,1);

    // Espera 100ms
    vTaskDelay(pdMS_TO_TICKS(100));

    // Desliga LED amarelo
    gpio_set_level(LED_AMARELO,0);

    // Espera 100ms
    vTaskDelay(pdMS_TO_TICKS(100));

    // Liga LED vermelho
    gpio_set_level(LED_VERMELHO,1);

    // Espera 100ms
    vTaskDelay(pdMS_TO_TICKS(100));

    // Desliga LED vermelho
    gpio_set_level(LED_VERMELHO,0);

    // Espera 100ms
    vTaskDelay(pdMS_TO_TICKS(100));

    // Parte abaixo faz LEDs piscarem invertidos

    // Garante vermelho desligado
    gpio_set_level(LED_VERMELHO,0);

    // Delay
    vTaskDelay(pdMS_TO_TICKS(100));

    // Liga vermelho
    gpio_set_level(LED_VERMELHO,1);

    // Delay
    vTaskDelay(pdMS_TO_TICKS(100));

    // Desliga vermelho
    gpio_set_level(LED_VERMELHO,0);

    // Desliga amarelo
    gpio_set_level(LED_AMARELO,0);

    // Delay
    vTaskDelay(pdMS_TO_TICKS(100));

    // Liga amarelo
    gpio_set_level(LED_AMARELO,1);

    // Delay
    vTaskDelay(pdMS_TO_TICKS(100));

    // Desliga amarelo
    gpio_set_level(LED_AMARELO,0);

    // Desliga verde
    gpio_set_level(LED_VERDE,0);

    // Delay
    vTaskDelay(pdMS_TO_TICKS(100));

    // Liga verde
    gpio_set_level(LED_VERDE,1);

    // Delay
    vTaskDelay(pdMS_TO_TICKS(100));

    // Desliga verde
    gpio_set_level(LED_VERDE,0);

    // Mostra mensagem de travessia
    printf("LIBERAR TRAVESSIA\n");

    // Tempo para pedestre atravessar
    vTaskDelay(pdMS_TO_TICKS(6000));

    // Zera pedidos pendentes após travessia
    pedestre_pendente = 0;
}

// Função principal do programa
void app_main(void)
{ 

    // Configura LED verde como saída
    gpio_set_direction(LED_VERDE,GPIO_MODE_OUTPUT);

    // Configura LED amarelo como saída
    gpio_set_direction(LED_AMARELO,GPIO_MODE_OUTPUT);

    // Configura LED vermelho como saída
    gpio_set_direction(LED_VERMELHO,GPIO_MODE_OUTPUT);

    // Variável não utilizada atualmente
    int counter = 0;

    // Estrutura de configuração do botão
    gpio_config_t io_conf = {

        // Seleciona o pino do botão
        .pin_bit_mask = (1ULL << BUTTON_GPIO),

        // Configura como entrada
        .mode = GPIO_MODE_INPUT,

        // Ativa resistor pull-up interno
        .pull_up_en = GPIO_PULLUP_ENABLE,
    }; 

    // Aplica configuração no hardware
    gpio_config(&io_conf);

    // Loop infinito do programa
    while (1)
    {

        // Executa ciclo normal apenas se não houver pedidos
        if (pedestre_pendente == 0)
        {

            // Estado verde
            seguir();

            // Estado amarelo
            atençao();

            // Estado vermelho
            parar();

            // Se existir pedido de travessia
            if (pedestre_pendente > 0)
            {

                // Executa travessia
                travessia ();

                // Reinicia o loop principal
                continue;
            }
        }
    }
}
